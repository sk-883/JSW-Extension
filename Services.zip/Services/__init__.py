# app/__init__.py
from main import app

# Optionally expose a factory:
# def app():
#     app = Flask(__name__)
#     # register blueprints, etc.
#     return app
